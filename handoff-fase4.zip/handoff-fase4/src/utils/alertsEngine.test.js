// Testes dos alertas reais. Data simulada fixa: "hoje" = 15/07/2026.

import { describe, it, expect, vi, beforeEach, afterEach } from "vitest";
import { buildFinancialAlerts, buildSalesAlerts, buildExpenseAlerts } from "./alertsEngine.js";

const HOJE = new Date(2026, 6, 15, 12, 0, 0);
const iso = (y, m, d) => new Date(y, m, d).toISOString();

const order = (id, m, d, total, cid = 1, nome = "Cliente A") => ({
  id, date: iso(2026, m, d), total, status: "recebida", client: { id: cid, name: nome }, items: [],
});
const payable = (id, situacao, m, d, valor, extra = {}) => ({
  id, situacao,
  vencimento: iso(2026, m, d),
  dataEmissao: iso(2026, m, d),
  valor,
  categoriaNome: "Compras",
  contato: { id, nome: "Fornecedor X" },
  ...extra,
});

beforeEach(() => { vi.useFakeTimers(); vi.setSystemTime(HOJE); });
afterEach(() => { vi.useRealTimers(); });

describe("buildSalesAlerts — quebra de fatura\u00e7\u00e3o", () => {
  it("gera alerta quando a fatura\u00e7\u00e3o cai forte face ao m\u00eas anterior", () => {
    const orders = [
      order(1, 6, 5, 2000),   // julho: 2.000
      order(2, 5, 5, 10000),  // junho: 10.000 => queda de 80%
    ];
    const alerts = buildSalesAlerts(orders);
    expect(alerts.some((a) => /quebra de fatura\u00e7\u00e3o/i.test(a.title))).toBe(true);
  });

  it("n\u00e3o gera alerta de quebra quando a fatura\u00e7\u00e3o cresce", () => {
    const orders = [
      order(1, 6, 5, 12000),
      order(2, 5, 5, 10000),
    ];
    const alerts = buildSalesAlerts(orders);
    expect(alerts.some((a) => /quebra de fatura\u00e7\u00e3o/i.test(a.title))).toBe(false);
  });
});

describe("buildExpenseAlerts — contas a pagar", () => {
  it("gera d-vencidas quando existe t\u00edtulo aberto com vencimento no passado", () => {
    const payables = [
      payable(1, 1, 6, 1, 5000), // aberto, venceu 01/07 (antes de 15/07)
      payable(2, 2, 6, 10, 1000), // pago: n\u00e3o conta como vencido
    ];
    const alerts = buildExpenseAlerts(payables);
    const vencidas = alerts.find((a) => a.id === "d-vencidas");
    expect(vencidas).toBeDefined();
    expect(vencidas.severity).toBe("danger");
    expect(vencidas.description).toContain("5.000,00");
  });

  it("gera d-proximos7 quando h\u00e1 t\u00edtulo aberto a vencer nos pr\u00f3ximos 7 dias", () => {
    const payables = [
      payable(1, 1, 6, 18, 2500), // aberto, vence 18/07 (em 3 dias)
    ];
    const alerts = buildExpenseAlerts(payables);
    const proximos = alerts.find((a) => a.id === "d-proximos7");
    expect(proximos).toBeDefined();
    expect(proximos.severity).toBe("warning");
  });

  it("t\u00edtulo aberto com vencimento distante n\u00e3o gera vencidas nem proximos7", () => {
    const payables = [
      payable(1, 1, 7, 20, 2500), // vence 20/08: fora da janela
    ];
    const ids = buildExpenseAlerts(payables).map((a) => a.id);
    expect(ids).not.toContain("d-vencidas");
    expect(ids).not.toContain("d-proximos7");
  });

  it("lista vazia devolve zero alertas (n\u00e3o inventar)", () => {
    expect(buildExpenseAlerts([])).toEqual([]);
    expect(buildExpenseAlerts(undefined)).toEqual([]);
  });
});

describe("buildExpenseAlerts \u2014 d-cat-mom (categoria em forte subida)", () => {
  const cat = (id, m, d, valor, categoria) => ({
    ...payable(id, 2, m, d, valor),
    categoriaNome: categoria,
  });

  it("dispara quando uma categoria sobe \u2265 50% com valor atual \u2265 500 \u20ac", () => {
    const payables = [
      cat(1, 6, 5, 900, "Marketing"),  // julho: 900
      cat(2, 5, 5, 500, "Marketing"),  // junho: 500 => +80%
      cat(3, 6, 6, 400, "Compras"),
      cat(4, 5, 6, 400, "Compras"),    // estavel: nao interfere
    ];
    const g = buildExpenseAlerts(payables).find((a) => a.id === "d-cat-mom");
    expect(g).toBeDefined();
    expect(g.severity).toBe("warning");
    expect(g.description).toContain("Marketing");
    expect(g.description).toContain("80%");
    expect(g.description).toContain("900,00");
  });

  it("n\u00e3o dispara com crescimento baixo, valor irrelevante ou categoria sem hist\u00f3rico", () => {
    const payables = [
      cat(1, 6, 5, 600, "Compras"),    // +20% (<50): nao dispara
      cat(2, 5, 5, 500, "Compras"),
      cat(3, 6, 6, 450, "Servicos"),   // +125% mas valor atual < 500: nao dispara
      cat(4, 5, 6, 200, "Servicos"),
      cat(5, 6, 7, 5000, "Nova"),      // sem mes anterior (antes = 0): nao dispara
    ];
    const ids = buildExpenseAlerts(payables).map((a) => a.id);
    expect(ids).not.toContain("d-cat-mom");
  });

  it("ignora \"Sem categoria\" mesmo com subida enorme", () => {
    const payables = [
      { ...payable(1, 2, 6, 5, 9000), categoriaNome: null },  // julho, sem categoria
      { ...payable(2, 2, 5, 5, 500), categoriaNome: null },   // junho
    ];
    const ids = buildExpenseAlerts(payables).map((a) => a.id);
    expect(ids).not.toContain("d-cat-mom");
  });
});

describe("buildFinancialAlerts — rentabilidade a partir da DRE", () => {
  const fmDe = (over = {}) => ({
    revenue: { net: 100000 },
    profitability: {
      netResult: 5000, netMarginPct: 25, ebitda: 8000,
      availability: { netResult: "real", netMarginPct: "real", ebitda: "real" },
      ...over,
    },
  });

  it("netResult NEGATIVO gera alerta, com impacto não monetário", () => {
    const out = buildFinancialAlerts({ financialMetrics: fmDe({ netResult: -1200, netMarginPct: -5 }), monthKey: "2026-06" });
    const a = out.find((x) => x.id === "f-resultado");
    expect(a).toBeTruthy();
    expect(a.severity).toBe("danger");
    expect(a.description).toContain("2026-06");
    expect(a.impacto).toBeUndefined(); // nunca quantifica impacto monetário
  });

  it("netResult POSITIVO e margem saudável não geram alerta", () => {
    const out = buildFinancialAlerts({ financialMetrics: fmDe(), monthKey: "2026-06" });
    expect(out.some((x) => x.id === "f-resultado")).toBe(false);
    expect(out.some((x) => x.id === "f-margem")).toBe(false);
  });

  it("netResult NULL (sem CMV) não gera qualquer alerta financeiro", () => {
    const semCmv = fmDe({ netResult: null, netMarginPct: null, ebitda: null,
      availability: { netResult: "unavailable", netMarginPct: "unavailable", ebitda: "unavailable" } });
    expect(buildFinancialAlerts({ financialMetrics: semCmv, monthKey: "2026-06" })).toEqual([]);
  });

  it("margem líquida baixa NÃO gera alerta (é apurada após retiradas dos sócios)", () => {
    // 4% de margem líquida com resultado positivo: sem regra aprovada, sem alerta.
    const out = buildFinancialAlerts({ financialMetrics: fmDe({ netResult: 300, netMarginPct: 4 }), monthKey: "2026-06" });
    expect(out.some((x) => x.id === "f-margem")).toBe(false);
    expect(out).toEqual([]);
  });

  it("só existem duas regras financeiras: resultado negativo e EBITDA negativo", () => {
    const ids = buildFinancialAlerts({
      financialMetrics: fmDe({ netResult: -100, netMarginPct: -1, ebitda: -50 }), monthKey: "2026-06",
    }).map((a) => a.id).sort();
    expect(ids).toEqual(["f-ebitda", "f-resultado"]);
  });

  it("o texto do resultado negativo explicita que é após retiradas", () => {
    const a = buildFinancialAlerts({ financialMetrics: fmDe({ netResult: -1200 }), monthKey: "2026-06" })
      .find((x) => x.id === "f-resultado");
    expect(a.title).toContain("após retiradas");
    expect(a.description).toContain("retiradas dos sócios");
  });

  it("EBITDA negativo gera alerta (regra nova desta fase)", () => {
    const out = buildFinancialAlerts({ financialMetrics: fmDe({ ebitda: -900 }), monthKey: "2026-06" });
    expect(out.some((x) => x.id === "f-ebitda")).toBe(true);
  });

  it("manual/mixed é usado mas conserva a origem no texto", () => {
    const mixed = fmDe({ netResult: -500, availability: { netResult: "mixed", netMarginPct: "mixed", ebitda: "mixed" } });
    const a = buildFinancialAlerts({ financialMetrics: mixed, monthKey: "2026-06" }).find((x) => x.id === "f-resultado");
    expect(a.description).toContain("inclui valor manual");
  });

  it("sem financialMetrics não há alertas financeiros", () => {
    expect(buildFinancialAlerts({})).toEqual([]);
    expect(buildFinancialAlerts({ financialMetrics: null })).toEqual([]);
  });

  it("nenhum alerta de CMV é criado (sem fonte automática)", () => {
    const out = buildFinancialAlerts({ financialMetrics: fmDe(), monthKey: "2026-06" });
    expect(out.some((x) => /cmv/i.test(x.id) || /cmv/i.test(x.title))).toBe(false);
  });
});

describe("buildSalesAlerts — comparação entre períodos", () => {
  const o = (id, mesIdx, total) => ({
    id: String(id), date: new Date(2026, mesIdx, 10).toISOString(), total,
    status: "recebida", client: { id: 1, name: "C" }, items: [],
  });
  // maio=4, junho=5, julho=6 (Date é 0-based)
  const orders = [o(1, 4, 10000), o(2, 5, 12000), o(3, 6, 300)];

  it("junho vs maio (ambos fechados) permite a comparação", () => {
    const out = buildSalesAlerts(orders, { monthKey: "2026-06", comparable: true });
    // +20% não atinge o limiar de subida (>=15% gera alerta de crescimento)
    expect(out.some((a) => a.id === "v-subida")).toBe(true);
    expect(out.some((a) => a.id === "v-queda")).toBe(false);
  });

  it("mês parcial (comparable false) NÃO gera alerta categórico de queda", () => {
    const out = buildSalesAlerts(orders, { monthKey: "2026-07", comparable: false });
    expect(out.some((a) => a.id === "v-queda")).toBe(false);
    expect(out.some((a) => a.id === "v-subida")).toBe(false);
  });

  it("sem mês injetado mantém o comportamento antigo", () => {
    const out = buildSalesAlerts(orders);
    expect(Array.isArray(out)).toBe(true);
  });
});

describe("buildSalesAlerts — produto, ticket e concentração no mês âncora", () => {
  // Date é 0-based: maio=4, junho=5, julho=6.
  const ord = (id, mesIdx, total, cliente, cid, prod, qty = 1) => ({
    id: String(id), date: new Date(2026, mesIdx, 10).toISOString(), total,
    status: "recebida", client: { id: cid, name: cliente },
    items: [{ productId: prod, code: prod, name: prod, qty, unitValue: total, total }],
  });

  // maio: Cliente A domina, produto P forte. junho: Cliente B, produto P estável.
  // julho (parcial): Cliente C, produto P em colapso e ticket muito baixo.
  const orders = [
    ord(1, 4, 9000, "Cliente A", 1, "P"), ord(2, 4, 1000, "Outro", 9, "Q"),
    ord(3, 5, 9500, "Cliente B", 2, "P"), ord(4, 5, 1000, "Outro", 9, "Q"), // Q estável maio->junho
    ord(5, 6, 200, "Cliente C", 3, "P"), ord(6, 6, 100, "Outro", 9, "Q"),
  ];
  const optsJunho = { monthKey: "2026-06", comparable: true };

  it("produto em queda compara junho vs maio, nunca julho vs junho", () => {
    const out = buildSalesAlerts(orders, optsJunho);
    const prod = out.find((a) => a.id === "v-prod");
    // P passou de 9000 (maio) para 9500 (junho): sem queda. Julho não entra.
    expect(prod).toBeFalsy();
  });

  it("sem mês âncora, o fallback antigo compararia julho (comportamento preservado)", () => {
    const out = buildSalesAlerts(orders);
    expect(out.some((a) => a.id === "v-prod")).toBe(true); // P caiu de 9500 para 200
  });

  it("comparable=false não gera queda de produto nem de ticket", () => {
    const out = buildSalesAlerts(orders, { monthKey: "2026-07", comparable: false });
    expect(out.some((a) => a.id === "v-prod")).toBe(false);
    expect(out.some((a) => a.id === "v-ticket")).toBe(false);
  });

  it("ticket médio: julho parcial não contamina o alerta de junho", () => {
    const out = buildSalesAlerts(orders, optsJunho);
    // ticket junho (5000) vs maio (5000): sem queda
    expect(out.some((a) => a.id === "v-ticket")).toBe(false);
  });

  it("concentração é a do mês âncora (Cliente B, não A nem C)", () => {
    const conc = buildSalesAlerts(orders, optsJunho).find((a) => a.id === "v-conc");
    expect(conc).toBeTruthy();
    expect(conc.description).toContain("Cliente B");
    expect(conc.description).not.toContain("Cliente A");
    expect(conc.description).not.toContain("Cliente C");
  });

  it("mudar o mês âncora muda o cliente concentrado", () => {
    const maio = buildSalesAlerts(orders, { monthKey: "2026-05", comparable: true }).find((a) => a.id === "v-conc");
    expect(maio.description).toContain("Cliente A");
    const julho = buildSalesAlerts(orders, { monthKey: "2026-07", comparable: true }).find((a) => a.id === "v-conc");
    expect(julho.description).toContain("Cliente C");
  });

  it("moeda: textos de vendas em R$, sem qualquer €", () => {
    const texto = buildSalesAlerts(orders, optsJunho).map((a) => a.description).join(" ");
    expect(texto).not.toContain("€");
    const comTicket = buildSalesAlerts([ord(1, 5, 1000, "A", 1, "P")], { monthKey: "2026-06", comparable: true })
      .map((a) => a.description).join(" ");
    expect(comTicket).toContain("R$");
  });
});